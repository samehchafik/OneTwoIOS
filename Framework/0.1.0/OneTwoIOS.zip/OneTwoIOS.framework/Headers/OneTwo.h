//
//  OneTwo.h
//  OneTwoIOS
//
//  Created by sameh chafik on 26/05/2018.
//  Copyright © 2018 Wonda VR. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OneTwo : NSObject
-(int)add:(int)a withB:(int)b;
@end
