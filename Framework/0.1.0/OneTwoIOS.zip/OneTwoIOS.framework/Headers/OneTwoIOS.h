//
//  OneTwoIOS.h
//  OneTwoIOS
//
//  Created by sameh chafik on 26/05/2018.
//  Copyright © 2018 Wonda VR. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for OneTwoIOS.
FOUNDATION_EXPORT double OneTwoIOSVersionNumber;

//! Project version string for OneTwoIOS.
FOUNDATION_EXPORT const unsigned char OneTwoIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OneTwoIOS/PublicHeader.h>

#import "OneTwo.h"


